﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microservices.WebApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace Microservices.WebApi.Controllers
{
    public class WeatherForecast {
        
    }

    [Route("api/[controller]")]
    public class ForecastsController : Controller
    {
        private IForecastService _service;

        public ForecastsController(IForecastService service){
            _service = service;
        }

        // GET api/forecasts
        [HttpGet]
        public IEnumerable<WeatherForecast> GetAll()
        {
            return _service.QueryAll();
        }

        // POST api/forecasts
        [HttpPost]
        public string SaveForecast(WeatherForecast forecast){
            return "success";
        }
    }
}
