﻿using System;
using FluentAssertions;
using Microservices.WebApi.Controllers;
using Microservices.WebApi.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Microservices.Tests.Controllers
{
    [TestClass]
    public class ForecastsControllerTest
    {
        private Mock<IForecastService> _forecastService;

        [TestInitialize]
        public void Init(){
            _forecastService = new Mock<IForecastService>();
        }

        [TestMethod]
        public void Has_GetAll(){
            // arrange
            var controller = new ForecastsController(_forecastService.Object);
            // act
            var response = controller.GetAll();
            // assert
            response.Should().NotBeNull();
        }

        [TestMethod]
        public void Calls_IForecastService() {
            // arrange

            var controller = new ForecastsController(_forecastService.Object);
            // act
            var response = controller.GetAll();
            // assert
            _forecastService.Verify(mn => mn.QueryAll(), Times.Once);
        }


        [TestMethod]
        public void Has_SaveForecast() {
            // arrange
            var controller = new ForecastsController(_forecastService.Object);
            var forecast = new WeatherForecast();
            // act 
            var response = controller.SaveForecast(forecast);
            // assert
            response.Should().NotBeNull();
        }
    }
}
