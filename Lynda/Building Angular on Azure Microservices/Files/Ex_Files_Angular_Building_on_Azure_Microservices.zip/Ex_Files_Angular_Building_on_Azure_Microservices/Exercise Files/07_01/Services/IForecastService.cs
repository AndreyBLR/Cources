﻿using System;
using System.Collections.Generic;
using AngularAzure.Dtos;

namespace AngularAzure.Services
{
    public interface IForecastService
    {
        IEnumerable<WeatherForecast> GetForecasts();
    }
}
