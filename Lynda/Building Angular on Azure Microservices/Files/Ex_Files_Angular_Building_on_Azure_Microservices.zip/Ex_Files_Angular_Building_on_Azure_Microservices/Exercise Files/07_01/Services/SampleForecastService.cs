﻿using System;
using System.Collections.Generic;
using System.Linq;
using AngularAzure.Dtos;
using Newtonsoft.Json;
using RestSharp;

namespace AngularAzure.Services
{
    public class SampleForecastService : IForecastService
    {
        private IAuthService _authService;

        public SampleForecastService(IAuthService authService){
            _authService = authService;
        }

        private static string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        public IEnumerable<WeatherForecast> GetForecasts()
        {
            // TODO: move params to config
            var auth = _authService.Auth(new AuthRequest
            {
                ClientId = "WAQYYYTEDsdlE610qKN0OTw9JX8yWzlN",
                ClientSecret = "QuBsNU6v7bCpNipYjGfKpnpCrVmQAncDch5n51gvj8xjVMhx8dfQ1EhvLtlww1v5",
                Audience = "api://forecasts",
                GrantType = "client_credentials"
            });

            // TODO: Move to configuration
            var restClient = new RestClient("http://microservices-webapi.azurewebsites.net/api/forecasts");
            var restRequest = new RestRequest(Method.GET);
            restRequest.AddHeader("Authorization", $"Bearer {auth.AccessToken}");
            var response = restClient.Execute(restRequest);
            return JsonConvert.DeserializeObject<WeatherForecast[]>(response.Content);
        }
    }
}
