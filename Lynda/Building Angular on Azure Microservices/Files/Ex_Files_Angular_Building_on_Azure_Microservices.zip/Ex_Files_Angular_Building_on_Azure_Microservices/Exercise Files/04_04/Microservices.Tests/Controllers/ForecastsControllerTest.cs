﻿using System;
using FluentAssertions;
using Microservices.WebApi.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Microservices.Tests.Controllers
{
    [TestClass]
    public class ForecastsControllerTest
    {
        [TestMethod]
        public void Has_GetAll(){
            // arrange
            var controller = new ForecastsController();
            // act
            var response = controller.GetAll();
            // assert
            response.Should().NotBeNull();
        }

        [TestMethod]
        public void Has_SaveForecast() {
            // arrange
            var controller = new ForecastsController();
            var forecast = new WeatherForecast();
            // act 
            var response = controller.SaveForecast(forecast);
            // assert
            response.Should().NotBeNull();
        }
    }
}
