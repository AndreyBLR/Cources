﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Microservices.WebApi.Controllers
{
    public class WeatherForecast {
        
    }

    [Route("api/[controller]")]
    public class ForecastsController : Controller
    {
        // GET api/forecasts
        [HttpGet]
        public IEnumerable<WeatherForecast> GetAll()
        {
            return new List<WeatherForecast>();
        }

        // POST api/forecasts
        [HttpPost]
        public string SaveForecast(WeatherForecast forecast){
            return "success";
        }
    }
}
